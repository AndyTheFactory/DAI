DROP TABLE customer;
